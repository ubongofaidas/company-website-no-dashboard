$(document).ready(function(){
    "use strict";
	$(".custom-toggler span").addClass('fa fa-bars');
	$(".custom-toggler").click(function(){
        $(".navbar").toggleClass('white-bg');
        $("#home-index .navbar a, #home-index .navbar span").toggleClass('toggled-home-index-nav-span');
		if($(".custom-toggler span").hasClass('fa fa-bars')){
			$(".custom-toggler span").removeClass('fa fa-bars').addClass('fa fa-times');
		}else{
			$(".custom-toggler span").removeClass('fa fa-times').addClass('fa fa-bars');
		}
	});
    //on scroll nav change
    $(window).scroll(function(event) {
		if( $(this).scrollTop() == 0 ){
			$(".navbar").removeClass('navbar-white');
		} else {
			$(".navbar").addClass('navbar-white');
            $("#home-index .navbar span").addClass('toggled-home-index-nav-span');
		}
	});
    //make this section no redirecting since no full page for club description(give only message)
    $('.clubs-section .item').on('click', function(e) {
        //alertify.set('notifier','delay', 5);
        alertify.set('notifier','position', 'top-center');
        alertify.error('we have nothing to show you this time');
    });
    //slider
    $('.owl-carousel').owlCarousel({
        loop: true,
        items: 3,
        margin: 10,
        nav: false,
        dots: true,
        autoplay:true,
        autoplayTimeout:3000,
        autoplayHoverPause:true,
        responsive:{
            0:{
                items: 1
            },
            600:{
                items: 2
            },
            1000:{
                items: 3
            }
        }
    })
    //video player
    const player = new Plyr('.preview-course');
    //smooth scroll
    $('html,body').animate({scrollTop:$(location.hash).offset().top}, 500);
    // Scroll to top button appear
    $(document).on('scroll', function() {
        var scrollDistance = $(this).scrollTop();
        if (scrollDistance > 100) {
            $('.scroll-to-top').fadeIn();
        } else {
            $('.scroll-to-top').fadeOut();
        }
    });
    // Smooth scrolling using jQuery easing
    $(document).on('click', 'a.scroll-to-top', function(e) {
    var $anchor = $(this);
    $('html, body').stop().animate({
        scrollTop: ($($anchor.attr('href')).offset().top)
    }, 1000, 'easeInOutExpo');
        e.preventDefault();
    });
});
//map
function initMap() {
    var uluru = {lat: -2.518592, lng: 32.899567};

    var map = new google.maps.Map(document.getElementById('map'), {zoom: 18, center: uluru});

    var marker = new google.maps.Marker({position: uluru, map: map});

}