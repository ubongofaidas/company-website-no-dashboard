# ttc_official_website

This website allow subscrition, contact and membership registration for anyone who join the startup.

The website for startup made with php, mysql and swiftmailer here you go, you can create a database with any name but rememberto change the name in connection file found in root/process/cnnect/connect.php and import database sql file found in root_folder to your server.

Then navigate to process/filenaeme_mailing.php set your email and pass in the following methods

    ->setUsername("putmail")
    ->setPassword("putpass");
    
Then go here https://symfony.com/doc/current/email.html ,read and go to gmail app where you can set your google to authorize email from other less secure app, finally  run your website while turned on internet and test for subscrition, contact and membership registration
